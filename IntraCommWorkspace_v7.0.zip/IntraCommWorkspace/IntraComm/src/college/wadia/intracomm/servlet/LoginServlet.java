package college.wadia.intracomm.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.utils.Constants;
import college.wadia.intracomm.utils.DBUtils;
import college.wadia.intracomm.utils.Utils;

@WebServlet(urlPatterns = { "/login" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
	}

	// Show Login page.
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Forward to /WEB-INF/views/loginView.jsp
		// (Users can not access directly into JSP pages placed in WEB-INF)
		RequestDispatcher dispatcher //
				= this.getServletContext().getRequestDispatcher("/WEB-INF/views/loginView.jsp");

		dispatcher.forward(request, response);

	}

	// When the user enters userName & password, and click Submit.
	// This method will be executed.
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String eEmailId = request.getParameter("eEmailId");
		String password = request.getParameter("ePassword");
		String rememberMeStr = request.getParameter("rememberMe");
		boolean remember = "Y".equals(rememberMeStr);

		Employee emp = null;
		boolean hasError = false;
		String errorString = null;

		if (eEmailId == null || password == null || eEmailId.length() == 0 || password.length() == 0) {
			hasError = true;
			errorString = "Required username and password!";
		} else {
			Connection conn = Utils.getStoredConnection(request);
			try {
				// Find the user in the DB.
				if(!eEmailId.endsWith(Constants.COMPANY_DOMAIN_SUFIX)) {
					eEmailId += Constants.COMPANY_DOMAIN_SUFIX; // append @domain
				}
				emp = DBUtils.findEmp(conn, eEmailId, password);

				if (emp == null) {
					hasError = true;
					errorString = "User Name or password invalid";
				}
			} catch (SQLException e) {
				e.printStackTrace();
				hasError = true;
				errorString = e.getMessage();
			}
		}
		// If error, forward to /WEB-INF/views/login.jsp
		if (hasError) {
			emp = new Employee();
			emp.seteEmailId(eEmailId);
			emp.setePassword(password);

			// Store information in request attribute, before forward.
			request.setAttribute("errorString", errorString);
			request.setAttribute("emp", emp);

			// show popup
			PrintWriter out = response.getWriter();
			out.println("<tr><td><input type='button' name='Button' value='Search' onclick=\"showPopUp();\"></td></tr>");

			// Forward to /WEB-INF/views/login.jsp
			RequestDispatcher dispatcher //
					= this.getServletContext().getRequestDispatcher("/WEB-INF/views/loginView.jsp");

			dispatcher.forward(request, response);
		}
		// If no error
		// Store user information in Session
		// And redirect to userInfo page.
		else {
			HttpSession session = request.getSession();
			Utils.storeLoginedUser(session, emp);

			// If user checked "Remember me".
			if (remember) {
				Utils.storeUserCookie(response, emp);
			}
			// Else delete cookie.
			else {
				Utils.deleteUserCookie(response);
			}

			// Redirect to userInfo page.
			response.sendRedirect(request.getContextPath() + "/userInfo");
		}
	}

}
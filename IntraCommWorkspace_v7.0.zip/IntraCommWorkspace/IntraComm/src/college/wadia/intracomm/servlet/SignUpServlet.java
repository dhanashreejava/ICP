package college.wadia.intracomm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.utils.Constants;
import college.wadia.intracomm.utils.DBUtils;
import college.wadia.intracomm.utils.Utils;

@WebServlet(urlPatterns = { "/signUp" })
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public SignUpServlet() {
		super();
	}

	// Show product creation page.
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/signUpView.jsp");
		dispatcher.forward(request, response);
	}

	// When the user enters the product information, and click Submit.
	// This method will be called.
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection conn = Utils.getStoredConnection(request);

		String errorString = null;

		String eName = (String) request.getParameter("eName");
		String eEmailId = (String) request.getParameter("eEmailId");
		String ePassword = (String) request.getParameter("ePassword");
		String eRePassword = (String) request.getParameter("eRePassword");
		
		if(!ePassword.equals(eRePassword)) {
			errorString = "Password mismatch!";
		}
		
		// Takes the date from the form in String and converts it java.util.date which is how the buisness object is written
        java.util.Date doj = null;
        java.util.Date dob = null;
		try {
			doj = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("eDoj"));
	        dob= new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("eDob")); 
		} catch (ParseException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		} 

        // Takes date from java.util.date and converts it to java.sql.date		
        java.sql.Date eDoj = new java.sql.Date(doj.getTime());
        java.sql.Date eDob = new java.sql.Date(dob.getTime());
        
        String eLevelValue = request.getParameter("eLevel");
        
		int eLevel = Integer.parseInt(eLevelValue);

		// Email ID is the string literal [a-zA-Z_0-9]
		// with at least 1 character
		String regex = "\\w+";

		String reportToEmailId = (String) request.getParameter("eReportTo");
		if (reportToEmailId == null || !reportToEmailId.matches(regex)) {
			errorString = "Invalid reporting manager user id!";
		} else {
			reportToEmailId +=  Constants.COMPANY_DOMAIN_SUFIX; // append @domain
		}
		// check if manager present or not
		// Find the report to emp in the DB.
		Employee manager = null;
		try {
			manager = DBUtils.findEmp(conn, reportToEmailId);
		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}

		int eReportTo = manager.geteId();
		
		String eGenderValue = (String) request.getParameter("eGender");
		String eGender = null;
		if(eGenderValue.equalsIgnoreCase(Constants.GENDER_MALE)) {
			eGender = Constants.GENDER_MALE_M;
		} else {
			eGender = Constants.GENDER_FEMALE_F;
		}
		
		String ePhotoPath = null;
		
		if (eEmailId == null || !eEmailId.matches(regex)) {
			errorString = "Invalid user id!";
		} else {
			eEmailId += Constants.COMPANY_DOMAIN_SUFIX; // append @domain
		}
		
		// check if user already present
		// Find the user in the DB.
		Employee emp = null;
		try {
			emp = DBUtils.findEmp(conn, eEmailId);
		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}

		if(emp != null) {
			errorString = "Employee already exists!";
		}
		
		Employee newUser = new Employee(eName, eEmailId, ePassword, eDoj, eDob, eLevel,
				eReportTo, eGender, ePhotoPath);

		// Add new user to database
		if (errorString == null) {
			try {
				DBUtils.insertEmpployee(conn, newUser);
			} catch (SQLException e) {
				e.printStackTrace();
				errorString = e.getMessage();
			}
		}

		// Store information to request attribute, before forward to views.
		request.setAttribute("errorString", errorString);

		// If error, forward to Edit page.
		if (errorString != null) {
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/WEB-INF/views/signUpView.jsp");
			dispatcher.forward(request, response);
		}
		// If everything nice.
		// Redirect to the product listing page.
		else {
			response.sendRedirect(request.getContextPath() + "/login");
		}
	}

}
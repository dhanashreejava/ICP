package college.wadia.intracomm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.utils.Constants;
import college.wadia.intracomm.utils.DBUtils;
import college.wadia.intracomm.utils.Utils;

@WebServlet(urlPatterns = { "/forgotPassword" })
public class ForgotPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ForgotPasswordServlet() {
		super();
	}

	// Show product creation page.
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/forgotPasswordView.jsp");
		dispatcher.forward(request, response);
	}

	// When the user enters the product information, and click Submit.
	// This method will be called.
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection conn = Utils.getStoredConnection(request);

		String errorString = null;
		String successString = null;

		String eEmailId = (String) request.getParameter("eEmailId");

		// Email ID is the string literal [a-zA-Z_0-9]
		// with at least 1 character
		String regex = "\\w+";
		if (eEmailId == null || !eEmailId.matches(regex)) {
			errorString = "Invalid user id!";
		} else {
			eEmailId += Constants.COMPANY_DOMAIN_SUFIX; // append @domain
		}

		String ePassword = (String) request.getParameter("ePassword");
		String eRePassword = (String) request.getParameter("eRePassword");

		if (!ePassword.equals(eRePassword)) {
			errorString += " Password mismatch!";
		}

		int eSecurityPIN = Integer.parseInt(request.getParameter("eSecurityPIN"));

		if (eSecurityPIN != 1234) {
			errorString += " Security PIN invalid!";
		}

		// everything is ok
		if (errorString == null) {
			// check if user already present
			// Find the user in the DB.
			Employee emp = null;
			try {
				emp = DBUtils.findEmp(conn, eEmailId);
			} catch (SQLException e) {
				e.printStackTrace();
				errorString = e.getMessage();
			}

			if (emp == null) {
				errorString = "Employee does not exists! Sign Up as new User!";
			} else {
				emp.setePassword(ePassword);
				// Add new user to database
				try {
					DBUtils.updateEmployeePassword(conn, emp);
					successString = "New Password successfully updated!";
				} catch (SQLException e) {
					e.printStackTrace();
					errorString = e.getMessage();
				}
			}
		}

		// Store information to request attribute, before forward to views.
		request.setAttribute("errorString", errorString);
		request.setAttribute("successString", successString);

		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/forgotPasswordView.jsp");
		dispatcher.forward(request, response);
	}

}
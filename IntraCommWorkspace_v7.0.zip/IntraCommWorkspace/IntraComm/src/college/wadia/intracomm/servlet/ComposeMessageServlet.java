package college.wadia.intracomm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.beans.Message;
import college.wadia.intracomm.utils.DBUtils;
import college.wadia.intracomm.utils.Utils;

@WebServlet(urlPatterns = { "/composeMessage" })
public class ComposeMessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ComposeMessageServlet() {
		super();
	}

	// Show product edit page.
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();

		// Check User has logged on
		Employee loginedUser = Utils.getLoginedUser(session);

		// Not logged in
		if (loginedUser == null) {
			// Redirect to login page.
			response.sendRedirect(request.getContextPath() + "/login");
			return;
		}
		// Store info to the request attribute before forwarding.
		request.setAttribute("emp", loginedUser);

		Connection conn = Utils.getStoredConnection(request);

		// Set inbox and outbox count
		try {
			int inboxCount = DBUtils.getInboxMessagesCount(conn, loginedUser);
			int outboxCount = DBUtils.getOutboxMessagesCount(conn, loginedUser);
			request.setAttribute("inboxCount", inboxCount);
			request.setAttribute("outboxCount", outboxCount);
		} catch (SQLException e) {
			System.out.println("Inbox and Outbox message count fetch failed!");
		}


		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/composeMessageView.jsp");
		dispatcher.forward(request, response);

	}

	// After the user modifies the product information, and click Submit.
	// This method will be executed.
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session = request.getSession();

		// Check User has logged on
		Employee loginedUser = Utils.getLoginedUser(session);

		// Not logged in
		if (loginedUser == null) {
			// Redirect to login page.
			response.sendRedirect(request.getContextPath() + "/login");
			return;
		}
		
		// Store info to the request attribute before forwarding.
		request.setAttribute("emp", loginedUser);

		Connection conn = Utils.getStoredConnection(request);

		String errorString = null;
		String successString = null;
		
		String msgFrom = loginedUser.geteEmailId();
		String msgTo = request.getParameter("msgTo");
		String msgSubject = request.getParameter("msgSubject");
		String msgText = request.getParameter("msgText");
		
		Message msg = new Message(msgFrom, msgTo, msgSubject, msgText);
		try {
			DBUtils.insertMessage(conn, msg);
			successString = "Your message has been sent!";
		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}
		
		// Set inbox and outbox count
		try {
			int inboxCount = DBUtils.getInboxMessagesCount(conn, loginedUser);
			int outboxCount = DBUtils.getOutboxMessagesCount(conn, loginedUser);
			request.setAttribute("inboxCount", inboxCount);
			request.setAttribute("outboxCount", outboxCount);
		} catch (SQLException e) {
			System.out.println("Inbox and Outbox message count fetch failed!");
		}

		// Store info in request attribute, before forward to views
		request.setAttribute("errorString", errorString);
		request.setAttribute("successString", successString);

		// Forward to /WEB-INF/views/productListView.jsp
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/composeMessageView.jsp");
		dispatcher.forward(request, response);
	}
}
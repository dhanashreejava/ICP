package college.wadia.intracomm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.beans.LeaveApplication;
import college.wadia.intracomm.beans.Message;
import college.wadia.intracomm.utils.Constants;
import college.wadia.intracomm.utils.DBUtils;
import college.wadia.intracomm.utils.Utils;

@WebServlet(urlPatterns = { "/applyLeave" })
public class ApplyLeaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ApplyLeaveServlet() {
		super();
	}

	// Show product edit page.
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		Connection conn = Utils.getStoredConnection(request);

		// Check User has logged on
		Employee loginedUser = Utils.getLoginedUser(session);

		// Not logged in
		if (loginedUser == null) {
			// Redirect to login page.
			response.sendRedirect(request.getContextPath() + "/login");
			return;
		}

		String errorString = null;

		Employee manager = null;
		try {
			manager = DBUtils.findManager(conn, loginedUser);
		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}

		// Set inbox and outbox count
		try {
			int inboxCount = DBUtils.getInboxMessagesCount(conn, loginedUser);
			int outboxCount = DBUtils.getOutboxMessagesCount(conn, loginedUser);
			request.setAttribute("inboxCount", inboxCount);
			request.setAttribute("outboxCount", outboxCount);
		} catch (SQLException e) {
			System.out.println("Inbox and Outbox message count fetch failed!");
		}

		// Store info to the request attribute before forwarding.
		request.setAttribute("emp", loginedUser);
		request.setAttribute("manager", manager);

		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/applyLeaveView.jsp");
		dispatcher.forward(request, response);

	}

	// After the user modifies the product information, and click Submit.
	// This method will be executed.
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		Connection conn = Utils.getStoredConnection(request);

		// Check User has logged on
		Employee loginedUser = Utils.getLoginedUser(session);

		// Not logged in
		if (loginedUser == null) {
			// Redirect to login page.
			response.sendRedirect(request.getContextPath() + "/login");
			return;
		}

		String errorString = null;
		String successString = null;

		Employee manager = null;
		try {
			manager = DBUtils.findManager(conn, loginedUser);
		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}

		// Store info to the request attribute before forwarding.
		request.setAttribute("emp", loginedUser);
		request.setAttribute("manager", manager);

		String laApplicant = loginedUser.geteEmailId();
		String laType = request.getParameter("laType");
		String laReason = request.getParameter("laReason");

		// Takes the date from the form in String and converts it java.util.date which
		// is how the buisness object is written
		java.util.Date fromDateVal = null;
		java.util.Date toDateVal = null;
		try {
			fromDateVal = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("laFromDate"));
			toDateVal = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("laToDate"));
		} catch (ParseException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}

		// Takes date from java.util.date and converts it to java.sql.date
		java.sql.Date laFromDate = new java.sql.Date(fromDateVal.getTime());
		java.sql.Date laToDate = new java.sql.Date(toDateVal.getTime());

		String laApprover = manager.geteEmailId();
		
		LeaveApplication leaveApplication = new LeaveApplication(laApplicant, laType, laReason, laFromDate, laToDate, laApprover,
				Constants.LEAVE_STATUS_APPLIED);
		try {
			DBUtils.insertLeaveApplication(conn, leaveApplication);
			successString = "Your leave application has been sent for approval!";
		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}
		// Store info in request attribute, before forward to views
		request.setAttribute("errorString", errorString);
		request.setAttribute("successString", successString);

		// Forward to /WEB-INF/views/productListView.jsp
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/WEB-INF/views/applyLeaveView.jsp");
		dispatcher.forward(request, response);
	}
}
package college.wadia.intracomm.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.utils.Constants;
import college.wadia.intracomm.utils.Utils;

@WebServlet(urlPatterns = { "/logout" })
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LogoutServlet() {
		super();
	}

	// Show Login page.
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		// Check User has logged on
		Employee loginedUser = Utils.getLoginedUser(session);

		// Not logged in
		if (loginedUser != null) {
			loginedUser.seteName("");
		}
		
		// delete session and cookies of this user
		Utils.deleteLoginedUser(session, loginedUser);
		Utils.deleteUserCookie(response);

		// Redirect to userInfo page.
		response.sendRedirect(request.getContextPath() + "/home");
	}

	// When the user enters userName & password, and click Submit.
	// This method will be executed.
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		doGet(request, response);
	}

}
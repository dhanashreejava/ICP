package college.wadia.intracomm.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.beans.Message;
import college.wadia.intracomm.utils.DBUtils;
import college.wadia.intracomm.utils.Utils;

@WebServlet(urlPatterns = { "/userInfo" })
public class UserInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserInfoServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();

		// Check User has logged on
		Employee loginedUser = Utils.getLoginedUser(session);

		// Not logged in
		if (loginedUser == null) {
			// Redirect to login page.
			response.sendRedirect(request.getContextPath() + "/login");
			return;
		}
		
		Connection conn = Utils.getStoredConnection(request);

		// Set inbox and outbox count
		try {
			int inboxCount = DBUtils.getInboxMessagesCount(conn, loginedUser);
			int outboxCount = DBUtils.getOutboxMessagesCount(conn, loginedUser);
			request.setAttribute("inboxCount", inboxCount);
			request.setAttribute("outboxCount", outboxCount);
		} catch (SQLException e) {
			System.out.println("Inbox and Outbox message count fetch failed!");
		}
		
		// Store info to the request attribute before forwarding.
		request.setAttribute("emp", loginedUser);

		// If the user has logged in, then forward to the page
		// /WEB-INF/views/userInfoView.jsp
		RequestDispatcher dispatcher //
				= this.getServletContext().getRequestDispatcher("/WEB-INF/views/userInfoView.jsp");
		dispatcher.forward(request, response);

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
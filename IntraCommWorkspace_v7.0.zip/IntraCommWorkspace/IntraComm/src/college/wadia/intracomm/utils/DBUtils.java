package college.wadia.intracomm.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import college.wadia.intracomm.beans.Employee;
import college.wadia.intracomm.beans.LeaveApplication;
import college.wadia.intracomm.beans.Message;

public class DBUtils {

	public static Employee findEmp(Connection conn, String emailId, String password) throws SQLException {

		String sql = "Select e.e_id, e.e_name, e.e_email_id, "
				+ "e.e_password, e.e_gender, e.e_doj, e.e_dob, e.e_level, "
				+ "e.e_report_to, e.e_photo from employee e " //
				+ " where e.e_email_id = ? and e.e_password= ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, emailId);
		pstm.setString(2, password);
		ResultSet rs = pstm.executeQuery();

		if (rs.next()) {
			int eId = rs.getInt("e_id");
			String eName = rs.getString("e_name");
			String eEmailId = rs.getString("e_email_id");
			String ePassword = rs.getString("e_password");
			Date eDoj = rs.getDate("e_doj");
			Date eDob = rs.getDate("e_dob");
			int eLevel = rs.getInt("e_level");
			int eReportTo = rs.getInt("e_report_to");
			String eGender = rs.getString("e_gender");
			String ePhotoPath = rs.getString("e_photo");

			Employee emp = new Employee(eId, eName, eEmailId, ePassword, eDoj, eDob, eLevel, eReportTo, eGender,
					ePhotoPath);
			return emp;
		}
		return null;
	}

	public static Employee findEmp(Connection conn, String emailId) throws SQLException {

		String sql = "Select e.e_id, e.e_name, e.e_email_id, "
				+ "e.e_password, e.e_gender, e.e_doj, e.e_dob, e.e_level, "
				+ "e.e_report_to, e.e_photo from employee e " //
				+ " where e.e_email_id = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, emailId);
		ResultSet rs = pstm.executeQuery();

		if (rs.next()) {
			int eId = rs.getInt("e_id");
			String eName = rs.getString("e_name");
			String eEmailId = rs.getString("e_email_id");
			String ePassword = rs.getString("e_password");
			Date eDoj = rs.getDate("e_doj");
			Date eDob = rs.getDate("e_dob");
			int eLevel = rs.getInt("e_level");
			int eReportTo = rs.getInt("e_report_to");
			String eGender = rs.getString("e_gender");
			String ePhotoPath = rs.getString("e_photo");

			Employee emp = new Employee(eId, eName, eEmailId, ePassword, eDoj, eDob, eLevel, eReportTo, eGender,
					ePhotoPath);
			return emp;
		}
		return null;
	}

	public static Employee findManager(Connection conn, Employee emp) throws SQLException {

		String sql = "Select e.e_id, e.e_name, e.e_email_id, "
				+ "e.e_password, e.e_gender, e.e_doj, e.e_dob, e.e_level, "
				+ "e.e_report_to, e.e_photo from employee e " //
				+ " where e.e_id = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setInt(1, emp.geteReportTo());
		ResultSet rs = pstm.executeQuery();

		if (rs.next()) {
			int eId = rs.getInt("e_id");
			String eName = rs.getString("e_name");
			String eEmailId = rs.getString("e_email_id");
			String ePassword = rs.getString("e_password");
			Date eDoj = rs.getDate("e_doj");
			Date eDob = rs.getDate("e_dob");
			int eLevel = rs.getInt("e_level");
			int eReportTo = rs.getInt("e_report_to");
			String eGender = rs.getString("e_gender");
			String ePhotoPath = rs.getString("e_photo");

			Employee manager = new Employee(eId, eName, eEmailId, ePassword, eDoj, eDob, eLevel, eReportTo, eGender,
					ePhotoPath);
			return manager;
		}
		return null;
	}
	

	public static List<Message> queryOutboxMessages(Connection conn, Employee emp) throws SQLException {
		String sql = "Select m.MsgId, m.MsgFrom, m.MsgTo, m.MsgSubject, m.MsgText, m.MsgTimestamp from Message m "
				+ "where m.MsgFrom = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, emp.geteEmailId());

		ResultSet rs = pstm.executeQuery();
		List<Message> list = new ArrayList<Message>();
		while (rs.next()) {
			int id = rs.getInt("MsgId");
			String from = rs.getString("MsgFrom");

			String fromName = findEmpName(conn, from);
			String to = rs.getString("MsgTo");
			
			StringBuffer toNameList = new StringBuffer();
			String values[]= to.split(";");
			for (String emailId: values) {
				toNameList.append(findEmpName(conn, emailId) + "; ");
			}	
			String subject = rs.getString("MsgSubject");
			String text = rs.getString("MsgText");
			Timestamp timestamp = rs.getTimestamp("MsgTimestamp");
			Message message = new Message(id, from, to, subject, text, timestamp);
			message.setMsgFromName(fromName);
			message.setMsgToNameList(toNameList.toString());
			list.add(message);
		}
		return list;
	}

	public static int getInboxMessagesCount(Connection conn, Employee emp) throws SQLException {
		String sql = "Select count(*) as inboxCount from Message m "
				+ "where m.MsgTo like ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, "%" + emp.geteEmailId() + "%");

		ResultSet rs = pstm.executeQuery();
		int inboxCount = 0;
		while (rs.next()) {
			inboxCount = rs.getInt("inboxCount");
		}
		return inboxCount;
	}

	public static int getOutboxMessagesCount(Connection conn, Employee emp) throws SQLException {
		String sql = "Select count(*) as outboxCount from Message m "
				+ "where m.MsgFrom like ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, "%" + emp.geteEmailId() + "%");

		ResultSet rs = pstm.executeQuery();
		int outboxCount = 0;
		while (rs.next()) {
			outboxCount = rs.getInt("outboxCount");
		}
		return outboxCount;
	}
	
	public static List<Message> queryInboxMessages(Connection conn, Employee emp) throws SQLException {
		String sql = "Select m.MsgId, m.MsgFrom, m.MsgTo, m.MsgSubject, m.MsgText, m.MsgTimestamp from Message m "
				+ "where m.MsgTo like ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, "%" + emp.geteEmailId() + "%");

		ResultSet rs = pstm.executeQuery();
		List<Message> list = new ArrayList<Message>();
		while (rs.next()) {
			int id = rs.getInt("MsgId");
			String from = rs.getString("MsgFrom");
			String fromName = findEmpName(conn, from);
			String to = rs.getString("MsgTo");
			
			StringBuffer toNameList = new StringBuffer();
			String values[]= to.split(";");
			for (String emailId: values) {
				toNameList.append(findEmpName(conn, emailId) + "; ");
			}			
			
			String subject = rs.getString("MsgSubject");
			String text = rs.getString("MsgText");
			Timestamp timestamp = rs.getTimestamp("MsgTimestamp");
			Message message = new Message(id, from, to, subject, text, timestamp);
			message.setMsgFromName(fromName);
			message.setMsgToNameList(toNameList.toString());
			list.add(message);
		}
		return list;
	}

	private static String findEmpName(Connection conn, String emailId) throws SQLException {
		String sql = "Select e.e_name from employee e where e.e_email_id = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, emailId);
		ResultSet rs = pstm.executeQuery();

		if (rs.next()) {
			return rs.getString("e_name");
		}
		
		return null;
	}

	public static List<LeaveApplication> queryLeaveApplications(Connection conn, Employee emp) throws SQLException {
		String sql = "Select la.la_id, la.la_applicant, la.la_type, la.la_reason, "
				+ "la.la_fromDate, la.la_toDate, la.la_approver, la.la_status, "
				+ "la.la_timestamp from leave_application la "
				+ "where la.la_applicant = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, emp.geteEmailId());

		ResultSet rs = pstm.executeQuery();
		List<LeaveApplication> list = new ArrayList<LeaveApplication>();
		while (rs.next()) {
			int id = rs.getInt("la_id");
			String applicant = rs.getString("la_applicant");
			String applicantName = findEmpName(conn, applicant); 
			String type = rs.getString("la_type");
			String reason = rs.getString("la_reason");
			Date fromDate = rs.getDate("la_fromDate");
			Date toDate = rs.getDate("la_toDate");
			String approver = rs.getString("la_approver");
			String approverName = findEmpName(conn, approver); 
			String status = rs.getString("la_status");
			Timestamp timestamp = rs.getTimestamp("la_timestamp");
			
			LeaveApplication la = new LeaveApplication(id, applicant, type, reason, fromDate, toDate, approver, status, timestamp);
			la.setApplicantName(applicantName);
			la.setApproverName(approverName);
			list.add(la);
		}
		return list;
	}
	
	public static List<LeaveApplication> queryTeamLeaveApplications(Connection conn, Employee emp) throws SQLException {
		String sql = "Select la.la_id, la.la_applicant, la.la_type, la.la_reason, "
				+ "la.la_fromDate, la.la_toDate, la.la_approver, la.la_status, "
				+ "la.la_timestamp from leave_application la "
				+ "where la.la_approver = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setString(1, emp.geteEmailId());

		ResultSet rs = pstm.executeQuery();
		List<LeaveApplication> list = new ArrayList<LeaveApplication>();
		while (rs.next()) {
			int id = rs.getInt("la_id");
			String applicant = rs.getString("la_applicant");
			String applicantName = findEmpName(conn, applicant); 
			String type = rs.getString("la_type");
			String reason = rs.getString("la_reason");
			Date fromDate = rs.getDate("la_fromDate");
			Date toDate = rs.getDate("la_toDate");
			String approver = rs.getString("la_approver");
			String approverName = findEmpName(conn, approver); 
			String status = rs.getString("la_status");
			Timestamp timestamp = rs.getTimestamp("la_timestamp");
			
			LeaveApplication la = new LeaveApplication(id, applicant, type, reason, fromDate, toDate, approver, status, timestamp);
			la.setApplicantName(applicantName);
			la.setApproverName(approverName);
			list.add(la);
		}
		return list;
	}

	public static List<Employee> queryTeamMembers(Connection conn, Employee emp) throws SQLException {
		String sql = "Select * from Employee e "
				+ "where e.e_Report_To = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setInt(1, emp.geteId());

		ResultSet rs = pstm.executeQuery();
		List<Employee> list = new ArrayList<Employee>();
		while(rs.next()) {
			int eId = rs.getInt("e_id");
			String eName = rs.getString("e_name");
			String eEmailId = rs.getString("e_email_id");
			String ePassword = rs.getString("e_password");
			Date eDoj = rs.getDate("e_doj");
			Date eDob = rs.getDate("e_dob");
			int eLevel = rs.getInt("e_level");
			int eReportTo = rs.getInt("e_report_to");
			String eGender = rs.getString("e_gender");
			String ePhotoPath = rs.getString("e_photo");

			// Ignore self record entry
			if(!eEmailId.equals(emp.geteEmailId())) {
				Employee em = new Employee(eId, eName, eEmailId, ePassword, eDoj, eDob, eLevel, eReportTo, eGender,
						ePhotoPath);
				Employee loginedUser = Utils.getLoginedUserMap().get(eEmailId);
				if(loginedUser != null) {
					em.seteStatus(Constants.USER_STATUS_ONLINE);
				}
				list.add(em);
			}
		}
		return list;
	}
	
	public static List<Message> queryTeamMessages(Connection conn, Employee emp) throws SQLException {
		String sql = "Select e.e_Email_Id from Employee e "
				+ "where e.e_Report_To = ?";

		PreparedStatement pstm = conn.prepareStatement(sql);
		pstm.setInt(1, emp.geteId());

		ResultSet rs = pstm.executeQuery();
		List<String> emailsList = new ArrayList<String>();
		while (rs.next()) {
			String emailId = rs.getString("e_Email_Id");
			
			// DO NOT add self e-mails in list
			if(!emailId.equals(emp.geteEmailId())) {
				emailsList.add(emailId);
			}
		}
		
		
		sql = "Select m.MsgId, m.MsgFrom, m.MsgTo, m.MsgSubject, m.MsgText, m.MsgTimestamp from Message m";
		pstm = conn.prepareStatement(sql);
		rs = pstm.executeQuery();
		
		List<Message> list = new ArrayList<Message>();
		while (rs.next()) {
			int id = rs.getInt("MsgId");
			String from = rs.getString("MsgFrom");
			String fromName = findEmpName(conn, from);
			String to = rs.getString("MsgTo");
			StringBuffer toNameList = new StringBuffer();
			String values[]= to.split(";");
			for (String emailId: values) {
				toNameList.append(findEmpName(conn, emailId) + "; ");
			}				
			String subject = rs.getString("MsgSubject");
			String text = rs.getString("MsgText");
			Timestamp timestamp = rs.getTimestamp("MsgTimestamp");

			for (String emailId : emailsList) {

				if (from.contains(emailId) || to.contains(emailId)) {
					if (!(from.contains(emp.geteEmailId()) || to.contains(emp.geteEmailId()))) {
						Message message = new Message(id, from, to, subject, text, timestamp);
						message.setMsgFromName(fromName);
						message.setMsgToNameList(toNameList.toString());
						list.add(message);
						break;
					}
				}
			}
		}

		return list;
	}

	public static void updateEmployeePassword(Connection conn, Employee emp) throws SQLException {
		String sql = "Update Employee set e_password=? where e_email_id=? ";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, emp.getePassword());
		pstm.setString(2, emp.geteEmailId());

		pstm.executeUpdate();
	}

	public static void insertEmpployee(Connection conn, Employee emp) throws SQLException {
		String sql = "Insert into Employee(e_name, e_email_id, e_password, e_doj, e_dob, e_level, e_report_to, e_gender, e_photo) values (?,?,?,?,?,?,?,?,?)";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, emp.geteName());
		pstm.setString(2, emp.geteEmailId());
		pstm.setString(3, emp.getePassword());
		pstm.setDate(4, emp.geteDoj());
		pstm.setDate(5, emp.geteDob());
		pstm.setInt(6, emp.geteLevel());
		pstm.setInt(7, emp.geteReportTo());
		pstm.setString(8, emp.geteGender());
		pstm.setString(9, emp.getePhotoPath());

		pstm.executeUpdate();
	}

	public static void insertMessage(Connection conn, Message msg) throws SQLException {
		String sql = "Insert into Message(MsgFrom, MsgTo, MsgSubject, MsgText) values (?,?,?,?)";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, msg.getMsgFrom());
		pstm.setString(2, msg.getMsgTo());
		pstm.setString(3, msg.getMsgSubject());
		pstm.setString(4, msg.getMsgText());
		
		pstm.executeUpdate();
	}

	public static void insertLeaveApplication(Connection conn, LeaveApplication la) throws SQLException {
		String sql = "Insert into Leave_Application(la_applicant, la_type, la_reason, la_fromDate, la_toDate, la_approver, la_status) values (?, ?, ?, ?, ?, ?, ?)";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, la.getApplicant());
		pstm.setString(2, la.getType());
		pstm.setString(3, la.getReason());
		pstm.setDate(4, la.getFromDate());
		pstm.setDate(5, la.getToDate());
		pstm.setString(6, la.getApprover());
		pstm.setString(7, la.getStatus());
		
		pstm.executeUpdate();
	}

	public static void deleteLeaveApplication(Connection conn, String email_id) throws SQLException {
		String sql = "Delete From Leave_Application where e_email_id= ?";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, email_id);

		pstm.executeUpdate();
	}
	
	public static void deleteEmployee(Connection conn, String email_id) throws SQLException {
		String sql = "Delete From Employee where e_email_id= ?";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, email_id);

		pstm.executeUpdate();
	}

	public static void deleteMessage(Connection conn, String email_id) throws SQLException {
		String sql = "Delete From Employee where e_email_id= ?";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, email_id);

		pstm.executeUpdate();
	}

	public static void updateLeaveStaus(Connection conn, int leaveId, String updateStaus) throws SQLException {
		String sql = "Update leave_application set la_status=? where la_id=? ";

		PreparedStatement pstm = conn.prepareStatement(sql);

		pstm.setString(1, updateStaus);
		pstm.setInt(2, leaveId);

		pstm.executeUpdate();		
	}

}
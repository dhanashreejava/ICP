package college.wadia.intracomm.utils;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import college.wadia.intracomm.beans.Employee;

public class Utils {

	public static final String ATT_NAME_CONNECTION = "ATTRIBUTE_FOR_CONNECTION";

	private static final String ATT_ID_EMP_EMAIL_ID = "ATTRIBUTE_FOR_STORE_USER_ID_IN_COOKIE";
	
	private static Map<String, Employee> loginedUserMap = new HashMap<>();

	public static Map<String, Employee> getLoginedUserMap() {
		return loginedUserMap;
	}

	// Store Connection in request attribute.
	// (Information stored only exist during requests)
	public static void storeConnection(ServletRequest request, Connection conn) {
		request.setAttribute(ATT_NAME_CONNECTION, conn);
	}

	// Get the Connection object has been stored in attribute of the request.
	public static Connection getStoredConnection(ServletRequest request) {
		Connection conn = (Connection) request.getAttribute(ATT_NAME_CONNECTION);
		return conn;
	}

	// Store user info in Session.
	public static void storeLoginedUser(HttpSession session, Employee loginedUser) {
		// On the JSP can access via ${loginedUser}
		session.setAttribute("loginedUser", loginedUser);
		if(loginedUser!=null)
			loginedUserMap.put(loginedUser.geteEmailId(), loginedUser);
	}
	

	// Get the user information stored in the session.
	public static Employee getLoginedUser(HttpSession session) {
		Employee loginedUser = (Employee) session.getAttribute("loginedUser");
		return loginedUser;
	}

	// Store info in Cookie
	public static void storeUserCookie(HttpServletResponse response, Employee emp) {
		System.out.println("Store user cookie");
		Cookie cookieUserName = new Cookie(ATT_ID_EMP_EMAIL_ID, emp.geteEmailId());
		// 1 day (Converted to seconds)
		cookieUserName.setMaxAge(24 * 60 * 60);
		response.addCookie(cookieUserName);
	}

	public static String getUserNameInCookie(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (Cookie cookie : cookies) {
				if (ATT_ID_EMP_EMAIL_ID.equals(cookie.getName())) {
					return cookie.getValue();
				}
			}
		}
		return null;
	}

	// Delete cookie.
	public static void deleteUserCookie(HttpServletResponse response) {
		Cookie cookieUserName = new Cookie(ATT_ID_EMP_EMAIL_ID, null);
		// 0 seconds (This cookie will expire immediately)
		cookieUserName.setMaxAge(0);
		response.addCookie(cookieUserName);
	}

	// delete session
	public static void deleteLoginedUser(HttpSession session, Employee loginedUser) {
		// On the JSP can access via ${loginedUser}
		session.invalidate();
		loginedUserMap.remove(loginedUser.geteEmailId());	
	}	
}
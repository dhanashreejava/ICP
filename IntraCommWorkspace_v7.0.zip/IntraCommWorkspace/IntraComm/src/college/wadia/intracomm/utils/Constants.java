package college.wadia.intracomm.utils;

public interface Constants {
	String COMPANY_DOMAIN_SUFIX = "@ipc.com";
	

	String GENDER_MALE_M = "M";
	String GENDER_FEMALE_F = "F";
	
	String GENDER_MALE = "male";
	String GENDER_FEMALE = "female";
	
	String USER_STATUS_ONLINE = "ONLINE";
	String USER_STATUS_OFFLINE = "OFFLINE";
	
	String LEAVE_STATUS_APPLIED = "APPLIED";
	String LEAVE_STATUS_APPROVED = "APPROVED";
	String LEAVE_STATUS_REJECTED = "REJECTED";
	
	String LT_SL 	= "SL";
	String LT_EL 	= "EL";
	String LT_SpL 	= "SpL";
	String LT_ML 	= "ML";
	String LT_LOPL 	= "LOPL";
	String LT_COL 	= "COL";
}

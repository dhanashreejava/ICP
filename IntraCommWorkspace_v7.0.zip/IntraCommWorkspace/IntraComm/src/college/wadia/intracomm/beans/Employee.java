package college.wadia.intracomm.beans;

import java.sql.Date;

import college.wadia.intracomm.utils.Constants;

public class Employee {
	private int eId; // PK
	private String eName;
	private String eEmailId; // UNIQUE
	private String ePassword;
	private Date eDoj;
	private Date eDob;
	private int eLevel;	// { 1: CEO, 2: HOD, 3: Manager, 4: Engineer }
	private int eReportTo; // FK	
	private String eGender;
	private String ePhotoPath;
	private String eStatus = Constants.USER_STATUS_OFFLINE;

	public Employee() {

	}

	public Employee(int eId, String eName, String eEmailId, String ePassword, Date eDoj, Date eDob, int eLevel,
			int eReportTo, String eGender, String ePhotoPath) {
		super();
		this.eId = eId;
		this.eName = eName;
		this.eEmailId = eEmailId;
		this.ePassword = ePassword;
		this.eDoj = eDoj;
		this.eDob = eDob;
		this.eLevel = eLevel;
		this.eReportTo = eReportTo;
		this.eGender = eGender;
		this.ePhotoPath = ePhotoPath;
	}
	
	public Employee(String eName, String eEmailId, String ePassword, Date eDoj, Date eDob, int eLevel,
			int eReportTo, String eGender, String ePhotoPath) {
		super();
//		this.eId = eId;
		this.eName = eName;
		this.eEmailId = eEmailId;
		this.ePassword = ePassword;
		this.eDoj = eDoj;
		this.eDob = eDob;
		this.eLevel = eLevel;
		this.eReportTo = eReportTo;
		this.eGender = eGender;
		this.ePhotoPath = ePhotoPath;
	}

	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String geteEmailId() {
		return eEmailId;
	}

	public void seteEmailId(String eEmailId) {
		this.eEmailId = eEmailId;
	}

	public String getePassword() {
		return ePassword;
	}

	public void setePassword(String ePassword) {
		this.ePassword = ePassword;
	}

	public Date geteDoj() {
		return eDoj;
	}

	public void seteDoj(Date eDoj) {
		this.eDoj = eDoj;
	}

	public Date geteDob() {
		return eDob;
	}

	public void seteDob(Date eDob) {
		this.eDob = eDob;
	}

	public int geteLevel() {
		return eLevel;
	}

	public void seteLevel(int eLevel) {
		this.eLevel = eLevel;
	}

	public int geteReportTo() {
		return eReportTo;
	}

	public void seteReportTo(int eReportTo) {
		this.eReportTo = eReportTo;
	}

	public String geteGender() {
		return eGender;
	}

	public void seteGender(String eGender) {
		this.eGender = eGender;
	}

	public String getePhotoPath() {
		return ePhotoPath;
	}

	public void setePhotoPath(String ePhotoPath) {
		this.ePhotoPath = ePhotoPath;
	}

	public String geteStatus() {
		return eStatus;
	}

	public void seteStatus(String eStatus) {
		this.eStatus = eStatus;
	}	
}
package college.wadia.intracomm.beans;

import java.sql.Timestamp;

public class Message {

	private int msgId;
	private String msgFrom;
	private String msgTo;
	private String msgSubject;
	private String msgText;
	private Timestamp msgTimestamp;

	// not saved in DB, only for UI
	String msgFromName;
	String msgToNameList;
	
	public Message() {
	}

	public Message(String msgFrom, String msgTo, String msgSubject, String msgText) {
		this.msgFrom = msgFrom;
		this.msgTo = msgTo;
		this.msgSubject = msgSubject;
		this.msgText = msgText;
	}

	public Message(int msgId, String msgFrom, String msgTo, String msgSubject, String msgText, Timestamp msgTimestamp) {
		this.msgId = msgId;
		this.msgFrom = msgFrom;
		this.msgTo = msgTo;
		this.msgSubject = msgSubject;
		this.msgText = msgText;
		this.msgTimestamp = msgTimestamp;
	}

	public int getMsgId() {
		return msgId;
	}

	public void setMsgId(int msgId) {
		this.msgId = msgId;
	}

	public String getMsgFrom() {
		return msgFrom;
	}

	public void setMsgFrom(String msgFrom) {
		this.msgFrom = msgFrom;
	}

	public String getMsgTo() {
		return msgTo;
	}

	public void setMsgTo(String msgTo) {
		this.msgTo = msgTo;
	}

	public String getMsgSubject() {
		return msgSubject;
	}

	public void setMsgSubject(String msgSubject) {
		this.msgSubject = msgSubject;
	}

	public String getMsgText() {
		return msgText;
	}

	public void setMsgText(String msgText) {
		this.msgText = msgText;
	}

	public Timestamp getMsgTimestamp() {
		return msgTimestamp;
	}

	public void setMsgTimestamp(Timestamp msgTimestamp) {
		this.msgTimestamp = msgTimestamp;
	}
	public String getMsgFromName() {
		return msgFromName;
	}

	public void setMsgFromName(String msgFromName) {
		this.msgFromName = msgFromName;
	}

	public String getMsgToNameList() {
		return msgToNameList;
	}

	public void setMsgToNameList(String msgToNameList) {
		this.msgToNameList = msgToNameList;
	}
}
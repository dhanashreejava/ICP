package college.wadia.intracomm.beans;

import java.sql.Date;
import java.sql.Timestamp;

import college.wadia.intracomm.utils.Constants;

public class LeaveApplication {

	private int id;
	private String applicant;
	private String type;
	private String reason;
	private Date fromDate;
	private Date toDate;
	private String approver;
	private String status = Constants.LEAVE_STATUS_APPLIED;
	private Timestamp timestamp;
	
	// not saved in DB, only for UI
	String applicantName;
	String approverName;
	
	public LeaveApplication(String applicant, String type, String reason, Date fromDate, Date toDate,
			String approver, String status) {
		this.applicant = applicant;
		this.type = type;
		this.reason = reason;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.approver = approver;
		this.status = status;
	}

	public LeaveApplication(int id, String applicant, String type, String reason, Date fromDate, Date toDate,
			String approver, String status, Timestamp msgTimestamp) {
		this.id = id;
		this.applicant = applicant;
		this.type = type;
		this.reason = reason;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.approver = approver;
		this.status = status;
		this.timestamp = msgTimestamp;
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getApplicant() {
		return applicant;
	}


	public void setApplicant(String applicant) {
		this.applicant = applicant;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getReason() {
		return reason;
	}


	public void setReason(String reason) {
		this.reason = reason;
	}


	public Date getFromDate() {
		return fromDate;
	}


	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}


	public Date getToDate() {
		return toDate;
	}


	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}


	public String getApprover() {
		return approver;
	}


	public void setApprover(String approver) {
		this.approver = approver;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Timestamp getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}
}
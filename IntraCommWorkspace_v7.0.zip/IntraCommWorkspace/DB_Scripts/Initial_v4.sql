-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2018 at 06:37 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `ipc`
--
CREATE DATABASE IF NOT EXISTS `ipc` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ipc`;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `E_ID` int(11) NOT NULL AUTO_INCREMENT,
  `E_NAME` varchar(255) NOT NULL,
  `E_EMAIL_ID` varchar(255) NOT NULL,
  `E_PASSWORD` text NOT NULL,
  `E_DOJ` date NOT NULL,
  `E_DOB` date NOT NULL,
  `E_LEVEL` int(11) NOT NULL,
  `E_REPORT_TO` int(11) NOT NULL COMMENT 'FK of E_ID',
  `E_GENDER` varchar(2) NOT NULL,
  `E_PHOTO` varchar(255) DEFAULT NULL COMMENT 'Name of img',
  PRIMARY KEY (`E_ID`),
  UNIQUE KEY `E_ID` (`E_ID`),
  UNIQUE KEY `E_MAIL_ID` (`E_EMAIL_ID`),
  KEY `E_REPORT_TO` (`E_REPORT_TO`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `employee`:
--   `E_REPORT_TO`
--       `employee` -> `E_ID`
--   `E_REPORT_TO`
--       `employee` -> `E_ID`
--

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`E_ID`, `E_NAME`, `E_EMAIL_ID`, `E_PASSWORD`, `E_DOJ`, `E_DOB`, `E_LEVEL`, `E_REPORT_TO`, `E_GENDER`, `E_PHOTO`) VALUES
(1, 'Ganesh', 'gs@ipc.com', 'sg123', '2018-01-01', '1985-04-08', 1, 1, 'M', NULL),
(2, 'Surendra', 'sd@ipc.com', 'sd123', '2018-01-01', '1983-05-08', 2, 1, 'M', NULL),
(3, 'Dheeraj', 'dg@ipc.com', 'dg123', '2018-01-01', '1981-05-08', 3, 2, 'M', NULL),
(4, 'Supriya', 'sj@ipc.com', 'sj123', '2018-01-01', '1990-01-01', 4, 3, 'F', NULL),
(5, 'Namrata', 'nk@ipc.com', 'nk123', '2018-01-01', '1985-02-10', 4, 3, 'F', NULL),
(6, 'Anam', 'aq@ipc.com', 'aq123', '2018-01-01', '1985-03-20', 4, 3, 'M', NULL),
(7, 'Santosh', 'sl@ipc.com', 'sl123', '2018-01-01', '1985-03-20', 3, 2, 'M', NULL),
(8, 'Dhanashree', 'sp@ipc.com', 'dp123', '2018-12-31', '2018-12-31', 4, 1, 'F', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leave_application`
--

DROP TABLE IF EXISTS `leave_application`;
CREATE TABLE IF NOT EXISTS `leave_application` (
  `la_id` int(11) NOT NULL AUTO_INCREMENT,
  `la_applicant` varchar(255) NOT NULL,
  `la_type` varchar(10) NOT NULL,
  `la_reason` text NOT NULL,
  `la_fromDate` date NOT NULL,
  `la_toDate` date NOT NULL,
  `la_approver` varchar(255) NOT NULL,
  `la_status` varchar(255) NOT NULL,
  `la_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`la_id`),
  KEY `la_applicant` (`la_applicant`),
  KEY `la_approver` (`la_approver`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `leave_application`:
--   `la_applicant`
--       `employee` -> `E_EMAIL_ID`
--   `la_approver`
--       `employee` -> `E_EMAIL_ID`
--

--
-- Dumping data for table `leave_application`
--

INSERT INTO `leave_application` (`la_id`, `la_applicant`, `la_type`, `la_reason`, `la_fromDate`, `la_toDate`, `la_approver`, `la_status`, `la_timestamp`) VALUES
(1, 'sp@ipc.com', 'SL', 'Not feeling well today', '2018-04-03', '2018-04-04', 'gs@ipc.com', 'APPLIED', '2018-04-03 19:14:28');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `MsgId` int(11) NOT NULL AUTO_INCREMENT,
  `MsgFrom` text NOT NULL,
  `MsgTo` text NOT NULL,
  `MsgSubject` text NOT NULL,
  `MsgText` text NOT NULL,
  `MsgTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`MsgId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `message`:
--

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`MsgId`, `MsgFrom`, `MsgTo`, `MsgSubject`, `MsgText`, `MsgTimestamp`) VALUES
(1, 'gs@ipc.com', 'nk@ipc.com;sp@ipc.com;dg@ipc.com', 'project work', 'Hi All,\r\n\r\nComeple work EOD.\r\n\r\nThanks,\r\nGanesh', '2018-04-01 17:52:18'),
(2, 'nk@ipc.com', 'gs@ipc.com;sp@ipc.com;dg@ipc.com', 'project work', 'Hi All,\r\n\r\nDone EOD.\r\n\r\nThanks,\r\nGanesh', '2018-04-01 17:52:44'),
(3, 'nk@ipc.com', 'sp@ipc.com;dg@ipc.com', 'project work', 'Hi All,\r\n\r\nDone EOD.\r\n\r\nThanks,\r\nGanesh', '2018-04-01 17:52:44');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`E_REPORT_TO`) REFERENCES `employee` (`E_ID`);

--
-- Constraints for table `leave_application`
--
ALTER TABLE `leave_application`
  ADD CONSTRAINT `leave_application_ibfk_1` FOREIGN KEY (`la_applicant`) REFERENCES `employee` (`E_EMAIL_ID`),
  ADD CONSTRAINT `leave_application_ibfk_2` FOREIGN KEY (`la_approver`) REFERENCES `employee` (`E_EMAIL_ID`);
